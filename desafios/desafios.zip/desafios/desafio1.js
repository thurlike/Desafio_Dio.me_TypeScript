// Como podemos rodar isso em um arquivo .ts sem causar erros? 


interface Funcionario {  
    code: number,
   name: string
};

let jhon: Funcionario = {
code : 10
name : 'John'
};